try {
    var active_item_width=0;
    var jewel=jQuery.noConflict();
	jewel(document).delegate('.ui-page', 'touchmove', false);
    var active_item="galssimagediv_head";
        var front_uploaded_flag=false;
        var side_uploaded_flag=false;
        var global_view ="Front";
        var video_streaming=false;
        var tryOnImgUrl='';
        var tryOnSideImgUrl='';
        var productid='';
        function convert_canvas_jewelfit(){
          var link=document.getElementById("linkimage_jewelfit");
          html2canvas(document.getElementById("image_download_jewelfit")).then(function(canvas) {
          var dt = canvas.toDataURL('image/png').replace("image/png", "image/octet-stream");
          link.href = dt;
          link.setAttribute("download","Face.png");
        });
            
      }
        jewel( function() {
    jewel( "#galssimagediv_ear" ).draggable();
    //jewel( "#TryOnModal-dialog-jewelfit" ).draggable();
    jewel( "#galssimagediv_ear" ).resizable();
    jewel( "#galssimagediv_neck" ).draggable();
    jewel( "#galssimagediv_neck" ).resizable();
    jewel( "#galssimagediv_ear_2" ).draggable();
    jewel( "#galssimagediv_ear_2" ).resizable();
    jewel( "#galssimagediv_head" ).draggable();
    jewel( "#galssimagediv_head" ).resizable();

            
  } );
        function setActiveItem(active_div)
        {
          active_item=active_div;
          console.log(active_item);
        }
        
        rotate=0;
      
        
        function rotate_jewelfit(degree){
            document.getElementById(active_item).style.webkitTransform="rotate("+degree+"deg)";     
}
        function zoom_out(size){
            console.log(size)
            var width= jewel("#"+active_item).width();
            console.log("update width"+width)
            if(active_item_width==0){
                active_item_width=width;
                console.log("inital width="+active_item_width );
            }
            jewel("#"+active_item).width( parseInt(active_item_width) + parseInt(size)+"px") ;
           
        }
       
        function save_image_jewelfit(el){
            jewel(el).css("display","none");
            var download_link=jewel("#linkimage_jewelfit");
            download_link.css("display","inline-block");
            convert_canvas_jewelfit();
        }
        function show_save_jewelfit(el){
            jewel(el).css("display","none");
            var download_link=jewel("#save_btn_jewelfit");
            download_link.css("display","inline-block");
        }
        function upload_jewelfit(){
          console.log("click");
            jewel("#imageLoader_jewelfit").click();
        }
}
catch(err){
  console.log(err.message);
}

try{
 function handleImage_jewelfit(e){
                    var video = jewel("#video_jewelfit");video.css("display","none");
                    video_streaming=false;

                     var canvas1 = jewel("#imageCanvas_jewelfit");
                      var front_uploaded=jewel("#front_uploaded_jewelfit");
                    var reader = new FileReader();
                    reader.onload = function(event){        
                        var img_uploaded_front = new Image();
                        img_uploaded_front.onload = function(){
                            canvas1.css("display","none");
                            
                                front_uploaded.css("display","block");
                                front_uploaded.attr("src",img_uploaded_front.src);
                  
                            convert_canvas_jewelfit();
                            var download_link=jewel("#save_btn_jewelfit");
                            download_link.css("display","inline-block");
                        }
                    img_uploaded_front.src = event.target.result;
                    convert_canvas_jewelfit();
                    }
                    reader.readAsDataURL(e.target.files[0]);     
                }
                
               
  }
catch(err){
  console.log(err.message);
}
try{     
        navigator.getUserMedia = ( navigator.getUserMedia ||
                             navigator.webkitGetUserMedia ||
                             navigator.mozGetUserMedia ||
                             navigator.msGetUserMedia);

      var video_stream;
      var webcamStream;

      function startWebcam_jewelfit() {

        if (location.protocol != 'https:')
{
 alert("WebCam is not allowed for http websites due to security reasons.Please switch to https for using webcam.");
}
else{       
            
            video_streaming=true;
            var save_btn=jewel("#save_btn_jewelfit");
            var download_btn=jewel("#linkimage_jewelfit");
            var capture_btn=jewel("#capture_btn_jewelfit");
            download_btn.css("display","none");
            save_btn.css("display","none");
            capture_btn.css("display","block");
            var canvas1 = jewel("#imageCanvas_jewelfit");
            var front_uploaded = jewel("#front_uploaded_jewelfit");
            var video = jewel("#video_jewelfit");
            canvas1.css("display","none");
            front_uploaded.css("display","none");
            video.css("display","block");
        if (navigator.getUserMedia) {
           navigator.getUserMedia (

              // constraints
              {
                 video: true,
                 audio: false
              },

              // successCallback
              function(stream) {
                  video_stream = document.getElementById("video_jewelfit");
                 video_stream.srcObject = stream;
                 webcamStream = stream;
              },

              // errorCallback
              function(err) {
               video_streaming=false;
               //if any error comes then video streaming will not be shown
               video.css("display","none");
                 console.log("The following error occured: " + err);
              }
           );
        } else {
        video_streaming=false;
           console.log("getUserMedia not supported");
        }  
      }
}
      function stopWebcam_jewelfit() {
          webcamStream.stop();
      }
      //---------------------
      // TAKE A SNAPSHOT CODE
      //---------------------
      
      

      function snapshot_jewelfit() {
        var neck= jewel("#galssimagediv_neck").css("display","block");
             var ear2= jewel("#galssimagediv_ear_2").css("display","block");
               var ear= jewel("#galssimagediv").css("display","block");
              var head= jewel("#galssimagediv_head").css("display","block");
        var save_btn=jewel("#save_btn_jewelfit");
            var download_btn=jewel("#linkimage_jewelfit");
            var capture_btn=jewel("#capture_btn_jewelfit");
            download_btn.css("display","none");
            capture_btn.css("display","none");
           save_btn.css("display","block");
      video_streaming=false
            var canvas1 = jewel("#imageCanvas_jewelfit");
            var front_uploaded = jewel("#front_uploaded_jewelfit");
          var c1=jewel("#c_jewelfit");
         // Draws current image from the video element into the canvas
          var canvas = document.getElementById("c_jewelfit");
          var v1=document.getElementById("video_jewelfit");
          var wid=v1.offsetWidth;
         var het=v1.offsetHeight;
         canvas.height=het;
         canvas.width=wid;
          document.getElementById("video_jewelfit").style.display="none";
         // canvas.getContext("2d").drawImage(video_stream, 0, 0, 480,630,0,0,350,400);
          canvas.getContext("2d").drawImage(video_stream,5,5,wid,het);
          var src1=canvas.toDataURL("image/png");
          if(global_view=="Front"){
                front_uploaded_flag=true;
                canvas1.css("display","none");
                front_uploaded.css("display","block");
                front_uploaded.attr("src",src1);
            }
            else{
                front_uploaded.css("display","none");
                canvas1.css("display","none");
            }
            
            convert_canvas_jewelfit();
            var download_link=jewel("#download_btn_jewelfit");
            download_link.css("display","inline-block");
           
      }

      jewel("#imageLoader_jewelfit").ready(function(){
         	var imageLoader = document.getElementById('imageLoader_jewelfit');
		  if(imageLoader){
            imageLoader.addEventListener('change', handleImage_jewelfit, false);
            var canvas1 = jewel("#imageCanvas_jewelfit");
            var front_uploaded = jewel("#front_uploaded_jewelfit");
            var view=jewel("#side_btn_jewelfit").text();
	  }
}); 
      }
catch(err){
  console.log(err.message);
}